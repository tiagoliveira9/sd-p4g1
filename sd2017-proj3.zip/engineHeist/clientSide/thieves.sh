
java -Djava.rmi.server.codebase="http://l040101-ws01.ua.pt/sd0401/projecto3/classes/"\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     ClientSide.ThiefClient
