/**
* Client side of implementation of Heist the museum.
* This package contains the active entities (master thief and ordinary thieves),
* and the stubs (except the GRIStub). Also contains the ClientCom class.
*
* @author Tiago Oliveira, tiago9@ua.pt, no.: 51687
* @author João Cravo, joao.cravo@ua.pt, no.: 63784
*/
package ClientSide;
