package ServerSide;

import Interfaces.InterfaceAssaultParty;
import Interfaces.InterfaceGRInformation;
import Auxiliary.Constants;
import Auxiliary.Triple;
import Auxiliary.Tuple;
import Auxiliary.VectorClk;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.rmi.RemoteException;

/**
 * This data type implements Assault party.
 *
 * @author João Cravo joao.cravo@ua.pt n.:63784
 * @author Tiago Oliveira tiago9@ua.pt n.:51687
 */
public class AssaultParty implements InterfaceAssaultParty {

    private static final AssaultParty[] instances = new AssaultParty[Constants.N_ASSAULT_PARTY];
    private final int partyId;
    private final static Lock l = new ReentrantLock();
    private final Condition moveThief;
    private final Condition shutCondition;
    private int[] line; // order that thieves blocks for the first time awaiting orders
    private Crook[] squad;
    private int distance; // targeted room distance
    private int roomId;
    private int nCrook; // thief counter
    private int[] teamLineup;
    private int[] translatePos;
    private int teamHeadIn; // thief that goes on the front crawling IN
    private int teamHeadOut; // thief that goes on the front crawling OUT
    private int idGlobal;
    private int shutNow;

    private VectorClk localClk;

    private final InterfaceGRInformation repo;

    private class Crook {

        private final int id;
        private final int agility;
        private int pos;
        private boolean canvas;

        public Crook(int id, int agility) {
            this.id = id;
            this.agility = agility;
            pos = 0;
            canvas = false; // esta variavel talvez não seja necessária

        }
    }

    /**
     * The method returns Assault Party object.
     *
     * @param i Assault party counter
     * @param repo
     * @return Instance of assault party
     */
    public static AssaultParty getInstance(int i, InterfaceGRInformation repo) {
        l.lock();
        try {
            if (instances[i] == null) {
                instances[i] = new AssaultParty(i, repo);
            }
        } catch (Exception ex) {
            Logger.getLogger(ControlCollectionSite.class.getName()).log(Level.SEVERE, null, ex);
        }
        l.unlock();
        return instances[i];
    }

    /**
     * Private constructor for Doubleton.
     *
     * @param partyId Assault party identification
     */
    private AssaultParty(int partyId, InterfaceGRInformation repo) {
        this.partyId = partyId;
        roomId = -1;
        distance = -1;
        nCrook = 0;
        teamHeadIn = 0;
        teamHeadOut = 0;
        shutNow = -1;

        line = new int[Constants.N_SQUAD];
        squad = new Crook[Constants.N_SQUAD];
        for (int i = 0; i < Constants.N_SQUAD; i++) {
            line[i] = -1;
        }
        moveThief = l.newCondition();
        shutCondition = l.newCondition();
        idGlobal = -1;
        this.repo = repo;
        localClk = new VectorClk(0, Constants.VECTOR_CLOCK_SIZE);
    }

    /**
     * Add thief to AssaultParty#. Return a flag, so the Thief knows who is last
     * to wake the Master
     *
     * @param partyIdMsg Party identification message
     * @param ts Vector Clock
     * @return True if is the last Thief, false otherwise.
     */
    @Override
    public Tuple<VectorClk, Boolean> addToSquad(int thiefId, int thiefAgility,
            int partyIdMsg, VectorClk ts) throws RemoteException {

        l.lock();

        localClk.updateClk(ts);
        boolean flag = false;

        try {
            if (nCrook < Constants.N_SQUAD) {
                squad[nCrook] = new Crook(thiefId, thiefAgility);
                nCrook++;
                int i;
                for (i = 0; i < Constants.N_SQUAD; i++) {
                    if (line[i] == -1) {
                        line[i] = thiefId;
                        int id = thiefId + 1;
                        repo.setIdPartyElem(partyIdMsg, i, id, localClk.getCopyClk());
                        break;
                    }
                }
                if (nCrook == Constants.N_SQUAD) {
                    // last thief
                    flag = true;
                }
            }
        } finally {
            l.unlock();
        }

        return new Tuple<>(localClk, flag);
    }

    /**
     * Thief blocks waiting to assault. First thief is waken by the Master. The
     * others will be by there fellow teammates.
     *
     */
    @Override
    public void waitToStartRobbing(int thiefId, int partyId) throws RemoteException {
        l.lock();

        Crook c = getCrook(thiefId);
        try {
            // it's like they stop one after each other, a team line
            while (c.id != idGlobal) {
                moveThief.await();
            }

        } catch (InterruptedException ex) {
        }

        l.unlock();
    }

    /**
     * Thief crawls in.
     *
     * @param partyIdMsg Party identification message
     * @param ts Vector Clock
     * @return Thief to the right room of an assault party
     */
    @Override
    public Triple<VectorClk, Integer, Integer> crawlIn(int thiefId,
            int partyIdMsg, VectorClk ts) throws RemoteException {

        l.lock();
        localClk.updateClk(ts);
        Crook cr = getCrook(thiefId);
        int next = selectNext(thiefId);

        try {
            while (!crawlGo(true, cr, partyIdMsg)) {
                idGlobal = squad[next].id;
                moveThief.signalAll();
                while (cr.id != idGlobal) {
                    moveThief.await();
                }
            }
            idGlobal = squad[next].id;
            moveThief.signalAll();
            l.unlock();
            int[] roomIdAssault = getRoomIdToAssault(cr.id);
            return new Triple<>(localClk.getCopyClk(), roomIdAssault[0], roomIdAssault[1]);

        } catch (InterruptedException ex) {
            Logger.getLogger(AssaultParty.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(0);

        }

        l.unlock();
        int[] roomId = getRoomIdToAssault(cr.id);
        return new Triple<>(localClk.getCopyClk(), roomId[0], roomId[1]);

    }

    /**
     * Thief crawls out.
     *
     * @param partyIdMsg Party identification message
     * @param ts Vector Clock
     * @return Thief to the right room of an assault party
     */
    @Override
    public VectorClk crawlOut(int thiefId, int partyIdMsg,
            VectorClk ts) throws RemoteException {
        l.lock();

        localClk.updateClk(ts);
        Crook cr = getCrook(thiefId);
        int myElemId = myPositionTeam(thiefId);
        int next = selectNext(thiefId);

        try {
            repo.setStateThief(Constants.CRAWLING_OUTWARDS, cr.id, localClk.getCopyClk());

            while (cr.id != idGlobal) {
                moveThief.await();
            }
            cr.pos = 0;
            while (!crawlGo(false, cr, partyIdMsg)) {

                idGlobal = squad[next].id;
                moveThief.signalAll();

                while (cr.id != idGlobal) {
                    moveThief.await();
                }
            }
            // Remove myself from team
            line[myElemId] = -1;
            nCrook--;
            repo.resetIdPartyElem(partyIdMsg, myElemId, localClk.getCopyClk());

            idGlobal = squad[next].id;
            moveThief.signalAll();
            l.unlock();

            return localClk.getCopyClk();

        } catch (InterruptedException ex) {
            Logger.getLogger(AssaultParty.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(0);
        }

        l.unlock();
        return localClk.getCopyClk();
    }

    private boolean crawlGo(boolean way, Crook cr, int partyIdMsg) throws RemoteException {
        l.lock();

        boolean flagI = false;
        int elemId = myPositionTeam(cr.id);
        int teamHead;

        if (way) {
            teamHead = teamHeadIn;
        } else {
            teamHead = teamHeadOut;
        }
        do {
            localClk.incrementClkOut((cr.id + 1));
            int pos = cr.pos + cr.agility;

            if (pos <= teamHead) {
                while (true) {
                    if (teamLineup[pos] != -1) {
                        pos--;
                    } else {
                        // update elem position and registers
                        teamLineup[cr.pos] = -1;
                        cr.pos = pos;
                        teamLineup[pos] = elemId;
                        break;
                    }
                }
            } else {
                if (pos - teamHead > 3) {
                    teamLineup[cr.pos] = -1;
                    cr.pos = teamHead + 3;

                    if (cr.pos >= distance) {
                        cr.pos = distance;
                        if (way) {
                            repo.setPosElem(partyIdMsg, elemId,
                                    cr.pos, localClk.getCopyClk());
                        } else {
                            repo.setPosElem(partyIdMsg, elemId,
                                    translatePos[cr.pos], localClk.getCopyClk());
                        }
                        flagI = true;
                        break;
                    }
                    teamLineup[cr.pos] = elemId;
                } else {
                    teamLineup[cr.pos] = -1;
                    cr.pos = pos;
                    if (pos >= distance) {
                        cr.pos = distance;
                        if (way) {
                            repo.setPosElem(partyIdMsg, elemId, cr.pos,
                                    localClk.getCopyClk());
                        } else {
                            repo.setPosElem(partyIdMsg, elemId,
                                    translatePos[cr.pos], localClk.getCopyClk());
                        }
                        flagI = true;
                        break;
                    }
                    teamLineup[cr.pos] = elemId;
                }
            }
            if (way) {
                repo.setPosElem(partyIdMsg, elemId, cr.pos, localClk.getCopyClk());
            } else {
                repo.setPosElem(partyIdMsg, elemId, translatePos[cr.pos], localClk.getCopyClk());
            }
        } while (cr.pos - teamHead != 3);

        // register the new yellow shirt
        if (way) {
            teamHeadIn = cr.pos;
        } else {
            teamHeadOut = cr.pos;
        }
        // here he will be always 3 positions ahead or at room
        l.unlock();
        return flagI;
    }

    /**
     * Get a thief.
     *
     * @param thiefId Thief identification
     * @return Squad number
     */
    public Crook getCrook(int thiefId) {
        l.lock();
        int i;

        for (i = 0; i < Constants.N_SQUAD; i++) {
            if (squad[i].id == thiefId) {
                break;
            }
        }
        l.unlock();
        return squad[i];
    }

    /**
     * This method returns the Thief active and next in line to wake. This way
     * is possible to use the correct condition (array of conditions) to block
     * and wake up the next
     *
     * @param myThiefId Thief identification for each thief
     * @return Next Thief to crawl
     */
    public int selectNext(int myThiefId) {
        l.lock();
        int nextThiefLine = -1;
        int myPositionLine = myPositionTeam(myThiefId);

        // if I am the last, the next to awake is the first
        if (myPositionLine + 1 > 2) {
            nextThiefLine = 0;
        } else {
            nextThiefLine = myPositionLine + 1;
        }
        l.unlock();
        return nextThiefLine;
    }

    /**
     * Gives the position of the thief.
     *
     * @param myThiefId Thief identification for each thief
     * @return Position of thief
     */
    public int myPositionTeam(int myThiefId) {
        l.lock();
        int myPosition = -1;

        for (int i = 0; i < Constants.N_SQUAD; i++) {
            if (line[i] == myThiefId) {
                myPosition = i;
            }
        }
        l.unlock();
        return myPosition;
    }

    /**
     * Activates Assault Party. Wakes up the first Thief to block on the assault
     * party and changes the state of the Master
     */
    @Override
    public void sendAssaultParty(int partyId) {

        l.lock();
        // Master wakes up the first Thief to block on the team
        int i;
        for (i = 0; i < 3; i++) {
            if (squad[i].id == line[0]) {
                break;
            }
        }
        idGlobal = squad[i].id;
        moveThief.signalAll();
        l.unlock();
    }

    /**
     * Master provides information of the room to assault: distance and roomId.
     *
     * @param distance Room distance
     * @param roomId Room identification
     */
    @Override
    public void setUpRoom(int distance, int roomId, int partyId) {
        l.lock();
        try {
            this.distance = distance;
            this.roomId = roomId;
            teamHeadIn = 0;
            teamHeadOut = 0;
            idGlobal = -1;
            // thief are in position zero that doesn't count, so +1
            teamLineup = new int[distance + 1];
            translatePos = new int[distance + 1];
            for (int i = 0; i < distance + 1; i++) {
                teamLineup[i] = -1;
                translatePos[i] = distance - i;
            }

        } finally {
            l.unlock();
        }
    }

    /**
     * Add a canvas to the thief.
     *
     * @param elemId Element identification
     */
    @Override
    public void addCrookCanvas(int elemId, int partyId) {
        l.lock();
        Crook c = squad[elemId];
        c.canvas = true;
        l.unlock();

    }

    /**
     * Get room identification to assault.
     *
     * @param thiefId Thief identification
     * @return Room and element identification
     */
    public int[] getRoomIdToAssault(int thiefId) {
        return new int[]{
            roomId, myPositionTeam(thiefId)
        };
    }

    /**
     * Get room identification
     *
     * @return Room identification
     */
    public int getRoomId() {
        return roomId;
    }

    /**
     * Get room distance.
     *
     * @return Room distance
     */
    public int getDistance() {
        return distance;
    }

    /**
     * Get id from Assault Party.
     *
     * @return Assault party identification
     */
    public int getPartyId() {
        return partyId;
    }

    @Override
    public void shutdown() {

        l.lock();
        try {
            shutNow = Constants.PRESENTING_THE_REPORT;
            shutCondition.signal();
        } finally {
            l.unlock();
        }
    }

    @Override
    public boolean waitingForShutdown() {

        l.lock();
        try {
            while (shutNow != Constants.PRESENTING_THE_REPORT) {
                try {
                    shutCondition.await();
                } catch (InterruptedException ex) {
                }
            }
        } finally {
            l.unlock();
        }
        return true;
    }

}
