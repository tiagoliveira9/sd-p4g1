/**
* Auxiliary classes of implementation of Heist the museum.
* This package contains the auxiliary classes. 
* 
* @author Tiago Oliveira, tiago9@ua.pt, no.: 51687
* @author João Cravo, joao.cravo@ua.pt, no.: 63784
*/
package Auxiliary;
